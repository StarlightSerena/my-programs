class Demo {

    // Constructor Overloading
    Demo() {
        System.out.println("Default Constructor");
    }

    Demo(int a) {
        System.out.println("Constructor with one argument: " + a);
    }

    Demo(int a, int b) {
        System.out.println("Constructor with two arguments: " + (a + b));
    }

    // Method Overloading
    void add(int a, int b) {
        System.out.println("Addition (2 args): " + (a + b));
    }

    void add(int a, int b, int c) {
        System.out.println("Addition (3 args): " + (a + b + c));
    }
}

public class Main {
    public static void main(String[] args) {
        Demo d1 = new Demo();
        Demo d2 = new Demo(10);
        Demo d3 = new Demo(10, 20);

        d1.add(5, 6);
        d1.add(5, 6, 7);
    }
}