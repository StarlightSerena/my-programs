package customerpkg;

public class Customer {

    String customerName;

    public Customer(String name) {
        customerName = name;
    }

    public void displayCustomer() {
        System.out.println("Customer Name: " + customerName);
    }
}