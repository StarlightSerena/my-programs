import bankpkg.Account;
import customerpkg.Customer;
import transactionpkg.Transaction;
import utilpkg.BankUtility;

public class MainApp {

    public static void main(String[] args) {

        BankUtility util = new BankUtility();
        util.showBankMessage();

        Customer c = new Customer("Raj");
        c.displayCustomer();

        Account acc = new Account("Raj", 8000);
        acc.showAccount();

        Transaction t = new Transaction();
        t.deposit(3000);
        t.withdraw(1500);
    }
}