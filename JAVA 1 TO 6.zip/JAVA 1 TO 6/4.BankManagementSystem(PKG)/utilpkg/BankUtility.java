package utilpkg;

public class BankUtility {

    public void showBankMessage() {
        System.out.println("Welcome to Bank Management System");
    }
}