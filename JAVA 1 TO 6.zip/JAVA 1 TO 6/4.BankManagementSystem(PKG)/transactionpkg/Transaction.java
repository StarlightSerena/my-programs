package transactionpkg;

public class Transaction {

    public void deposit(double amount) {
        System.out.println("Amount Deposited: " + amount);
    }

    public void withdraw(double amount) {
        System.out.println("Amount Withdrawn: " + amount);
    }
}