package bankpkg;

public class Account {

    String holderName;
    double balance;

    public Account(String name, double bal) {
        holderName = name;
        balance = bal;
    }

    public void showAccount() {
        System.out.println("Account Holder: " + holderName);
        System.out.println("Account Balance: " + balance);
    }
}