import java.util.Scanner;

class Point {
    int xcoordinate;
    int ycoordinate;

    // Method to get values
    void getPoint(int x, int y) {
        xcoordinate = x;
        ycoordinate = y;
    }

    // Method to calculate distance
    double distancePoints(Point p) {
        int dx = this.xcoordinate - p.xcoordinate;
        int dy = this.ycoordinate - p.ycoordinate;
        return Math.sqrt(dx * dx + dy * dy);
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Point p1 = new Point();
        Point p2 = new Point();

        System.out.println("Enter x and y for Point 1:");
        p1.getPoint(sc.nextInt(), sc.nextInt());

        System.out.println("Enter x and y for Point 2:");
        p2.getPoint(sc.nextInt(), sc.nextInt());

        double distance = p1.distancePoints(p2);
        System.out.println("Distance between two points: " + distance);
    }
}