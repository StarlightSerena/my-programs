class University {
    String UnivName;
    String Address;

    void setUniversity(String name, String addr) {
        UnivName = name;
        Address = addr;
    }

    void displayUniversity() {
        System.out.println("University: " + UnivName);
        System.out.println("Address: " + Address);
    }
}

class School extends University {
    String SchoolName;
    int NoOfDepartments;

    void setSchool(String name, int num) {
        SchoolName = name;
        NoOfDepartments = num;
    }

    void displaySchool() {
        System.out.println("School: " + SchoolName);
        System.out.println("Departments: " + NoOfDepartments);
    }
}

class Department extends School {
    String DeptName;
    int NoOfProgrammes;

    void setDepartment(String name, int num) {
        DeptName = name;
        NoOfProgrammes = num;
    }

    void displayDepartment() {
        System.out.println("Department: " + DeptName);
        System.out.println("Programmes: " + NoOfProgrammes);
    }
}

class Programme extends Department {
    String ProgrammeName;
    int TotalStudents;

    void setProgramme(String name, int total) {
        ProgrammeName = name;
        TotalStudents = total;
    }

    void displayProgramme() {
        System.out.println("Programme: " + ProgrammeName);
        System.out.println("Total Students: " + TotalStudents);
    }
}

class Faculty extends Department {
    String FacultyName;
    int Experience;

    void setFaculty(String name, int exp) {
        FacultyName = name;
        Experience = exp;
    }

    void displayFaculty() {
        System.out.println("Faculty: " + FacultyName);
        System.out.println("Experience: " + Experience + " years");
    }
}

public class Main {
    public static void main(String[] args) {

        Programme p = new Programme();
        p.setUniversity("ABC University", "Bangalore");
        p.setSchool("Engineering", 5);
        p.setDepartment("CSE", 3);
        p.setProgramme("B.Tech", 200);

        p.displayUniversity();
        p.displaySchool();
        p.displayDepartment();
        p.displayProgramme();

        System.out.println("------------------");

        Faculty f = new Faculty();
        f.setUniversity("ABC University", "Bangalore");
        f.setSchool("Engineering", 5);
        f.setDepartment("CSE", 3);
        f.setFaculty("Dr. Rao", 10);

        f.displayUniversity();
        f.displaySchool();
        f.displayDepartment();
        f.displayFaculty();
    }
}