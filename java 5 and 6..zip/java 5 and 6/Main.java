abstract class Vehicle {
String brand = "Toyota";   // value (variable)


// Abstract method (no body)
abstract void speed();

// Concrete method
void displayBrand() {
    System.out.println("Brand: " + brand);
}


}

// Subclass
class Car extends Vehicle {

// Providing implementation for abstract method
void speed() {
    int maxSpeed = 180;
    System.out.println("Car Speed: " + maxSpeed + " km/h");
}


}

// Main class
public class Main {
public static void main(String[] args) {
Car c = new Car();


    c.displayBrand();  // accessing value from abstract class
    c.speed();         // implemented method
}


}
