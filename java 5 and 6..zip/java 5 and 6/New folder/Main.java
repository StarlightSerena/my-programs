interface OnlinePayment {
    int transactionFee = 10;

    void payOnline();
}

interface OfflinePayment {
    int cashLimit = 5000;

    void payOffline();
}

// Class implementing multiple interfaces
class Payment implements OnlinePayment, OfflinePayment {

    public void payOnline() {
        System.out.println("Online Payment with fee: " + transactionFee + " Rs");
    }

    public void payOffline() {
        System.out.println("Offline Payment limit: " + cashLimit + " Rs");
    }
}

// Main class
public class Main {
    public static void main(String[] args) {
        Payment p = new Payment();

        p.payOnline();
        p.payOffline();
    }
}